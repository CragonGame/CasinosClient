-- Copyright(c) Cragon. All rights reserved.

---------------------------------------
LanBase = class()

---------------------------------------
function LanBase:ctor()
end

---------------------------------------
function LanBase:getValue(key)
end

---------------------------------------
function LanBase:parseLanKeyValue(tb_datamgr)
end

---------------------------------------
function LanBase:getLanPackageName()
end

---------------------------------------
function LanBase:GetGoldShowStr(gold, show_short_way, precision_length)
end

---------------------------------------
function LanBase:GetGoldShowStr2(gold, show_short_way, precision_length)
end