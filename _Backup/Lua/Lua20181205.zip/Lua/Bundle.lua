-- Copyright(c) Cragon. All rights reserved.

---------------------------------------
CommonSelectPro = '1.00.000'
CommonSelectDev = '1.00.000'
DataSelectPro = '1.00.605'
DataSelectDev = '1.00.605'